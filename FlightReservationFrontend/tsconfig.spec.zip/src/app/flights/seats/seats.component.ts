import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-seats',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './seats.component.html',
  styleUrls: ['./seats.component.scss'],
})
export class Seats implements OnInit {

  flightId: number = 0;
  seats: any[] = [];
  selectedSeat: any = null;

  constructor(
    private route: ActivatedRoute,
    private http: HttpClient,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.flightId = Number(this.route.snapshot.paramMap.get('id'));
    this.loadSeats();
  }

  loadSeats() {
    this.http
      .get(`https://localhost:7055/api/flights/${this.flightId}/seats`)
      .subscribe({
        next: (res: any) => {
          this.seats = res;
        },
        error: (err) => console.error(err),
      });
  }

  selectSeat(seat: any) {
    if (seat.isReserved) return;
    this.selectedSeat = seat;
  }

  reserveSeat() {
    if (!this.selectedSeat) return;

    const userId = Number(localStorage.getItem('userId')); // TEMP

    const payload = {
      flightId: this.flightId,
      seatId: this.selectedSeat.id,
      userId: userId
    };

    this.http
      .post(`https://localhost:7055/api/reservations`, payload)
      .subscribe({
        next: () => {
          alert('Seat reserved!');
          this.router.navigate(['/my-reservations']);
        },
        error: (err) => console.error(err),
      });
  }
}
