import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, NavigationEnd } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent {

  currentRoute: string = '';

  constructor(
    private router: Router,
    public authService: AuthService
  ) {
    this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe((event: any) => {
        this.currentRoute = event.urlAfterRedirects;
      });
  }

  // REQUIRED METHODS
  isNotHome(): boolean {
    return this.currentRoute !== '/';
  }

  get userName(): string {
    return this.authService.getUserName();
  }

  goHome() {
    this.router.navigate(['/']);
  }

  goToSearch() {
    this.router.navigate(['/flights/search']);
  }

  goToMyReservations() {
    this.router.navigate(['/my-reservations']);
  }

  goToLogin() {
    this.router.navigate(['/login']);
  }

  goToRegister() {
    this.router.navigate(['/register']);
  }

  goToAdminFlights() {
    this.router.navigate(['/admin/flights']);
  }

  goToCreateFlight() {
    this.router.navigate(['/admin/flights/create']);
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/']);
  }
}