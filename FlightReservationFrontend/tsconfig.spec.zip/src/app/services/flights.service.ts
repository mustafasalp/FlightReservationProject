import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class FlightsService {
  private apiUrl = 'https://localhost:7055/api';

  constructor(private http: HttpClient) { }

  searchFlights(origin: string | null, destination: string | null, date: string | null, classes: string[] = []): Observable<any[]> {
    let params = new HttpParams();
    if (origin) params = params.set('origin', origin);
    if (destination) params = params.set('destination', destination);
    if (date) params = params.set('date', date);

    if (classes && classes.length > 0) {
      classes.forEach(c => {
        params = params.append('classes', c);
      });
    }

    console.log('Calling search API with params:', params.toString());
    return this.http.get<any[]>(`${this.apiUrl}/flights/search`, { params });
  }

  getAllFlights(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/flights`);
  }

  getFlightById(id: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/flights/${id}`);
  }
}
