import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatCheckboxModule } from '@angular/material/checkbox';

import { AuthService } from '../services/auth.service';
import { FlightsService } from '../services/flights.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatCheckboxModule
  ],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {

  searchModel = {
    from: '',
    to: '',
    date: null as string | null,
    classes: [] as string[],
  };

  cities = [
    'Istanbul',
    'Ankara',
    'Izmir',
    'Antalya',
    'Bursa',
    'Adana',
    'Gaziantep',
    'Konya',
    'London',
    'Paris',
    'Berlin',
    'Amsterdam',
    'Rome',
    'Madrid',
    'Dubai',
    'New York',
    'Los Angeles'
  ];

  logoutMessage = '';
  flights: any[] = [];
  loading = false;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    public auth: AuthService,
    private flightsService: FlightsService
  ) { }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      if (params['logout'] === 'true') {
        this.logoutMessage = 'Logged out successfully.';
        setTimeout(() => (this.logoutMessage = ''), 3000);
      }
    });

    // Don't load flights initially - only after search
  }

  // SEARCH
  onSearch() {
    this.loading = true;

    // Convert date to string format if it exists
    let dateString = null;
    if (this.searchModel.date) {
      const date = new Date(this.searchModel.date);
      dateString = date.toISOString().split('T')[0]; // Format: YYYY-MM-DD
    }

    const queryParams: any = {
      from: this.searchModel.from,
      to: this.searchModel.to,
      date: dateString
    };

    if (this.searchModel.classes.length > 0) {
      queryParams.classes = this.searchModel.classes.join(',');
    }

    console.log('Navigating to search with params:', queryParams);

    this.router.navigate(['/flights/search'], { queryParams: queryParams })
      .then(() => {
        this.loading = false;
      })
      .catch(err => {
        console.error('Navigation error:', err);
        this.loading = false;
      });
  }

  toggleClass(value: string, checked: boolean) {
    if (checked) {
      this.searchModel.classes.push(value);
    } else {
      this.searchModel.classes = this.searchModel.classes.filter(c => c !== value);
    }
  }

  goToDetails(id: number) {
    this.router.navigate(['/flights/details', id]);
  }

  // NAVIGATION SHORTCUTS
  goToLogin() { this.router.navigate(['/login']); }
  goToRegister() { this.router.navigate(['/register']); }
  goToMyReservations() { this.router.navigate(['/my-reservations']); }
  goToAdmin() { this.router.navigate(['/admin/flights/create']); }

  airlines = [
    { name: 'Turkish Airlines', logo: '/assets/TurkishAirlinesPhoto.jpg', url: 'https://www.turkishairlines.com' },
    { name: 'Pegasus Airlines', logo: '/assets/PegasusPhoto.png', url: 'https://www.flypgs.com' },
    { name: 'SunExpress', logo: '/assets/SunExpressAirlinesPhoto.jpeg', url: 'https://www.sunexpress.com' },
    { name: 'Emirates', logo: '/assets/emirates-airlines-seeklogo.png', url: 'https://www.emirates.com' },
    { name: 'Qatar Airways', logo: '/assets/qatar-airways.jpeg', url: 'https://www.qatarairways.com' },
    { name: 'British Airways', logo: '/assets/british-airways.jpeg', url: 'https://www.britishairways.com' },
    { name: 'Air France Airways', logo: '/assets/air-france-airways.jpeg', url: 'https://wwws.airfrance.com.tr' },
    { name: 'American Airlines', logo: '/assets/american-airways.jpeg', url: 'https://www.aa.com' },
    { name: 'Lufhansa Airlines', logo: '/assets/lufhansa-airways.jpeg', url: 'https://www.lufthansa.com' },
    { name: 'Easy Jet Airlines', logo: '/assets/easyjet-airways.jpeg', url: 'https://www.easyjet.com' },
  ];
}