import { Component } from '@angular/core';

@Component({
  selector: 'app-my-reservations',
  standalone: true,
  imports: [],
  templateUrl: './my-reservations.component.html',
  styleUrls: ['./my-reservations.component.scss'],
})
export class MyReservationsComponent {

}
