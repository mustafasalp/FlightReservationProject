import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AdminFlightsService } from '../../../core/services/admin-flights.service';

@Component({
    selector: 'app-admin-flights-list',
    standalone: true,
    imports: [CommonModule],
    templateUrl: './list.component.html',
    styleUrls: ['./list.component.scss']
})
export class ListFlightsComponent implements OnInit, OnDestroy {
    flights: any[] = [];
    loading = true;

    constructor(
        private adminFlightsService: AdminFlightsService,
        private router: Router
    ) { }

    ngOnInit() {
        console.log('[ListFlightsComponent] ngOnInit called');
        this.loadFlights();
    }

    ngOnDestroy() {
        console.log('[ListFlightsComponent] ngOnDestroy called');
    }

    loadFlights() {
        this.loading = true;
        console.log('[ListFlightsComponent] loadFlights called, loading =', this.loading);

        this.adminFlightsService.getFlights().subscribe({
            next: (data) => {
                console.log('[ListFlightsComponent] Flights loaded successfully:', data);
                this.flights = data;
                this.loading = false;
            },
            error: (err) => {
                console.error('[ListFlightsComponent] Error loading flights:', err);
                this.loading = false;
                if (err.status === 401) {
                    alert('Authentication failed. Please login as admin.');
                } else {
                    alert('Failed to load flights: ' + (err.error?.message || err.message || 'Unknown error'));
                }
            }
        });
    }

    editFlight(id: number) {
        this.router.navigate(['/admin/flights/edit', id]);
    }

    deleteFlight(id: number, flightNumber: string) {
        if (!confirm(`Are you sure you want to delete flight ${flightNumber}?`)) {
            return;
        }

        this.adminFlightsService.deleteFlight(id).subscribe({
            next: () => {
                alert('Flight deleted successfully');
                this.loadFlights(); // Reload the list
            },
            error: (err) => {
                console.error('Error deleting flight', err);
                const msg = err.error?.message || 'Failed to delete flight';
                alert(`Error: ${msg}`);
            }
        });
    }

    createFlight() {
        this.router.navigate(['/admin/flights/create']);
    }

    formatDate(date: string): string {
        return new Date(date).toLocaleString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }
}
