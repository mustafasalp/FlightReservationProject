import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AdminFlightsService } from '../../../core/services/admin-flights.service';

@Component({
  selector: 'app-edit-flight',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.scss']
})
export class EditFlightComponent implements OnInit {
  form: FormGroup;
  loading = false;
  flightId!: number;

  constructor(
    private fb: FormBuilder,
    private adminFlightsService: AdminFlightsService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.form = this.fb.group({
      flightNumber: ['', Validators.required],
      airline: ['', Validators.required],
      origin: ['', Validators.required],
      destination: ['', Validators.required],
      departureTime: ['', Validators.required],
      arrivalTime: ['', Validators.required],
      totalCapacity: [180, [Validators.required, Validators.min(1), Validators.max(500)]],
      basePrice: [1000, [Validators.required, Validators.min(0)]]
    });
  }

  ngOnInit() {
    this.flightId = Number(this.route.snapshot.paramMap.get('id'));
    this.loadFlight();
  }

  loadFlight() {
    this.loading = true;
    this.adminFlightsService.getFlightById(this.flightId).subscribe({
      next: (flight) => {
        // Convert datetime strings to the format required by datetime-local input
        const departureTime = this.formatDateTimeForInput(flight.departureTime);
        const arrivalTime = this.formatDateTimeForInput(flight.arrivalTime);

        this.form.patchValue({
          flightNumber: flight.flightNumber,
          airline: flight.airline,
          origin: flight.origin,
          destination: flight.destination,
          departureTime: departureTime,
          arrivalTime: arrivalTime,
          totalCapacity: flight.totalCapacity,
          basePrice: flight.basePrice
        });
        this.loading = false;
      },
      error: (err) => {
        console.error('Error loading flight', err);
        alert('Failed to load flight details');
        this.router.navigate(['/admin/flights']);
      }
    });
  }

  formatDateTimeForInput(dateString: string): string {
    const date = new Date(dateString);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    return `${year}-${month}-${day}T${hours}:${minutes}`;
  }

  submit() {
    if (this.form.invalid) return;

    this.loading = true;

    this.adminFlightsService.updateFlight(this.flightId, this.form.value).subscribe({
      next: () => {
        alert('Flight updated successfully!');
        this.router.navigate(['/admin/flights']);
      },
      error: (err) => {
        console.error('Update flight error', err);
        const msg = err.error?.title || err.message || 'Failed to update flight.';
        alert(`Error: ${msg}`);
        this.loading = false;
      }
    });
  }

  cancel() {
    this.router.navigate(['/admin/flights']);
  }
}
