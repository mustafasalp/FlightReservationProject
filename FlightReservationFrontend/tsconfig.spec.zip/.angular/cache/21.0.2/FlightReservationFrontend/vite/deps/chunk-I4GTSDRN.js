import {
  InjectionToken
} from "./chunk-O2Q6O3GJ.js";

// node_modules/@angular/material/fesm2022/_input-value-accessor-chunk.mjs
var MAT_INPUT_VALUE_ACCESSOR = new InjectionToken("MAT_INPUT_VALUE_ACCESSOR");

export {
  MAT_INPUT_VALUE_ACCESSOR
};
//# sourceMappingURL=chunk-I4GTSDRN.js.map
