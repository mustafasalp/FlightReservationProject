import {
  MatFormFieldModule
} from "./chunk-PPYJ6VYU.js";
import {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
} from "./chunk-HN35DGF7.js";
import "./chunk-AIESJSDV.js";
import "./chunk-OKDUMLH4.js";
import "./chunk-RXXVT7TQ.js";
import "./chunk-GUGIMSVJ.js";
import "./chunk-5CQ3CRSH.js";
import "./chunk-26Y3KHLM.js";
import "./chunk-DC6XKRN5.js";
import "./chunk-3ZZCDVLN.js";
import "./chunk-O2Q6O3GJ.js";
import "./chunk-RIOTEP5Z.js";
export {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
};
